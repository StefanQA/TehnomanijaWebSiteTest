package tests;

import pages.TehnomanijaLogin;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.interactions.Action;

import java.util.List;


public class TehnomanijaLoginTest extends BaseTest


{

@Test

        public void TehnomanijaPositiveLogin() throws InterruptedException
{
        TehnomanijaLogin tl = new TehnomanijaLogin(driver);
        tl.tehnomanijaPositiveLogin("stefansvelickovic@gmail.com","Stefanv88!");

        wdWait.until(ExpectedConditions.visibilityOfElementLocated(By.className("user-name")));
        WebElement usersName = driver.findElement(By.className("user-name"));
        Assert.assertTrue("User is not logged in",usersName.getText().contains("STEFAN"));
}
@Test
        public void TehnomanijaNegativeLogin() throws InterruptedException
{
        TehnomanijaLogin tl = new TehnomanijaLogin(driver);
        tl.tehnomanijaNegativeLogin("stefansvelickovic@gmail.com","Stefanv88");

        wdWait.until(ExpectedConditions.presenceOfElementLocated(By.className("wrapped")));
        WebElement failedLoginMessage = driver.findElement(By.className("wrapped"));
        Assert.assertTrue("User is logged in",failedLoginMessage.getText().contains("Pogrešan email ili lozinka!"));
}

}
