package tests;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import pages.TehnomanijaPriceFilter;
import pages.TehnomanijaSearchBox;
import pages.TehnomanijaSearchedProducts;
import pages.TehnomanijaShoppingCart;
import org.junit.Test;

import java.util.List;

public class TehnomanijaTest extends BaseTest
{
    @Test

    public void tehnomanijaShoppingCartTest() throws InterruptedException
    {
        TehnomanijaSearchBox tsb= new TehnomanijaSearchBox(driver);
        tsb.tehnomanijaSearchBox("iPhone SE2");
        TehnomanijaSearchedProducts tsp = new TehnomanijaSearchedProducts(driver);
        tsp.chooseRandomProduct();
        TehnomanijaShoppingCart tsc = new TehnomanijaShoppingCart(driver);
        tsc.productPrice();
        tsc.totalAmount();


        Assert.assertEquals("Product price and total amount are not equal",tsc.productPrice(),tsc.totalAmount(),0.0);
        //vizuelna konfirmacija
        Thread.sleep(4000);
    }

    @Test

    public void tehnomanijaSearchBoxTest() throws InterruptedException
    {
        pages.TehnomanijaSearchBox tsb = new pages.TehnomanijaSearchBox(driver);
        tsb.tehnomanijaSearchBox("iphone SE2");

        wdWait.until(ExpectedConditions.presenceOfElementLocated(By.className("js-product-grid-wrap")));
        WebElement list = driver.findElement(By.className("js-product-grid-wrap"));
        List<WebElement> productList = list.findElements(By.className("product-wrap-grid"));
        System.out.println("Number of items in productList is:"+productList.size());
        for (WebElement product : productList)
        {
            if (product.getText().contains("iPhone SE2"));
            Assert.assertTrue(product.getText().contains("iPhone SE2"));
            //vizuelna konfirmacija
            Thread.sleep(4000);
        }
    }


    @Test

    public void TehnomanijaPriceFilterTest() throws InterruptedException
    {
        TehnomanijaSearchBox tsb= new TehnomanijaSearchBox(driver);
        tsb.tehnomanijaSearchBox("elektricni trotineti");
        TehnomanijaPriceFilter tpf = new TehnomanijaPriceFilter(driver);
        tpf.insertMinAndMaxPrice("40000","50000");

        wdWait.until(ExpectedConditions.presenceOfElementLocated(By.className("js-product-grid-wrap")));
        WebElement list = driver.findElement(By.className("js-product-grid-wrap"));
        List<WebElement> productList = list.findElements(By.className("product-wrap-grid"));
        System.out.println("Number of items in productList is:"+productList.size());

        for (WebElement product:productList)
        {
            WebElement productPrice = product.findElement(By.className("price"));
            String productP = productPrice.getText();
            double productPriceToDouble = tpf.parcedPrice(productP);
            System.out.println("Price of listed product"+productPriceToDouble);

            Assert.assertTrue("Product prices are not in the filter range",40000<productPriceToDouble && productPriceToDouble< 50000);
        }

    }
}
