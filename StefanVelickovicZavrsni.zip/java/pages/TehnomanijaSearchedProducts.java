package pages;

import helpers.BaseHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;
import java.util.Random;


public class TehnomanijaSearchedProducts extends BaseHelper
{

    @FindBy (className = "basket-header")
    WebElement shopCart;

    WebDriver driver;

    public TehnomanijaSearchedProducts(WebDriver driver)
    {
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    public void chooseRandomProduct() throws InterruptedException
    {
        wdWait.until(ExpectedConditions.presenceOfElementLocated(By.className("products-wrap")));
        WebElement products = driver.findElement(By.className("products-wrap"));
        List <WebElement> productList = products.findElements(By.className("product-wrap-grid"));
        Random rand = new Random();
        int randomProduct = rand.nextInt(productList.size());
        js.executeScript("arguments[0].click();",productList.get(randomProduct).findElement(By.className("basket")));
        //vizuelna konfirmacija
        Thread.sleep(3000);
        shopCart.click();
    }


}


