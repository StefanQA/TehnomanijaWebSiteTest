package pages;

import helpers.BaseHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;
import java.util.Random;

public class TehnomanijaShoppingCart extends BaseHelper
{
    WebDriver driver;


    public TehnomanijaShoppingCart (WebDriver driver)
    {
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    public double parcedPrice(String priceAsString)
    {
        Double parsedString = Double.parseDouble(priceAsString.replace(".", "").replace("RSD", "").replace(",", "."));
        return parsedString;
    }

    public double productPrice()
    {
        wdWait.until(ExpectedConditions.presenceOfElementLocated(By.className("product-listing")));
        List<WebElement> products = driver.findElements(By.className("product-listing"));
        String productPrice = products.get(0).findElement(By.className("js-gross")).getText();
        double price = parcedPrice(productPrice);
        System.out.println("Price:"+price);
        return price;
    }

    public double totalAmount()
    {
        String totalPrice = driver.findElement(By.className("cart-summary-value")).getText();
        Double total=parcedPrice(totalPrice);
        System.out.println("Total price:"+total);
        return total;
    }


}
