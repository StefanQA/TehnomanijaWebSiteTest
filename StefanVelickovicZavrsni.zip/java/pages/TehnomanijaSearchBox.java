package pages;

import helpers.BaseHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class TehnomanijaSearchBox extends BaseHelper
{
    @FindBy(className = "search-field")
    WebElement searchBox;

    WebDriver driver;
    String navigateToTehnomanijaHomePage = "https://www.tehnomanija.rs/";

    public TehnomanijaSearchBox(WebDriver driver)
    {
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    public void tehnomanijaHomePage()
    {
        driver.get(navigateToTehnomanijaHomePage);
    }

    private void tehnomanijaSearchProducts(String product)
    {
    wdWait.until(ExpectedConditions.visibilityOf(searchBox));
    searchBox.sendKeys(product);
    searchBox.submit();
    }

    public void tehnomanijaSearchBox(String product)
    {
        tehnomanijaHomePage();
        tehnomanijaSearchProducts(product);
    }


}
