package pages;

import helpers.BaseHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

public class TehnomanijaPriceFilter extends BaseHelper
{
    @FindBy (className = "filter-content")
    WebElement priceFilterBox;
    @FindBy (id = "filter_price_min")
    WebElement minPriceBox;
    @FindBy (id = "filter_price_max")
    WebElement maxPriceBox;

    WebDriver driver;

    public TehnomanijaPriceFilter(WebDriver driver)
    {
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }


    public void insertMinAndMaxPrice(String minimumPrice, String maximumPrice)
    {
        wdWait.until(ExpectedConditions.visibilityOf(priceFilterBox));
        minPriceBox.sendKeys(minimumPrice);
        maxPriceBox.sendKeys(maximumPrice);
        WebElement submitButton = priceFilterBox.findElement(By.className("thm-icon4-right"));
        submitButton.click();
    }

    public double parcedPrice(String priceAsString)
    {
        Double parsedString = Double.parseDouble(priceAsString.replace(".", "").replace("RSD", "").replace(",", "."));
        return parsedString;
    }

}
