package pages;

import helpers.BaseHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class TehnomanijaLogin extends BaseHelper
{
    @FindBy(className = "user-wraper")
    WebElement userWraper;
    @FindBy(className = "js-header-email")
    WebElement emailField;
    @FindBy(className = "js-header-password")
    WebElement passwordField;
    @FindBy(className = "login-button")
    WebElement loginButton;

    WebDriver driver;
    String tehnomanijaHomePage = "https://www.tehnomanija.rs/";

    public TehnomanijaLogin(WebDriver driver)

    {
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }


    private void positiveLogin(String email, String password)
    {
        driver.get(tehnomanijaHomePage);
        wdWait.until(ExpectedConditions.visibilityOf(userWraper));
        userWraper.click();
        wdWait.until(ExpectedConditions.visibilityOfElementLocated(By.className("login-button")));
        emailField.sendKeys(email);
        passwordField.sendKeys(password);
        loginButton.click();
    }



    private void negativeLogin(String email, String password)
    {
        driver.get(tehnomanijaHomePage);
        wdWait.until(ExpectedConditions.visibilityOf(userWraper));
        userWraper.click();
        wdWait.until(ExpectedConditions.visibilityOfElementLocated(By.className("login-button")));
        emailField.sendKeys(email);
        passwordField.sendKeys(password);
        loginButton.click();
    }


    public void tehnomanijaPositiveLogin(String email, String password)
    {
        positiveLogin(email,password);
    }

    public void tehnomanijaNegativeLogin(String email, String password)
    {
        negativeLogin(email,password);
    }
}
